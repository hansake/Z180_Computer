# Z80 CPU for KiCAD. Includes Symbols for all the Z8, Z80, Z180, Z380 & preipherals types I could find.
